from fastapi import APIRouter, Depends, HTTPException, Query, Header, status
from sqlalchemy.orm import Session
import httpx
from typing import List, Optional
from . import models, schemas, database
from .database import get_db

router = APIRouter(
    prefix="/location",
    tags=["Location & Nearby Services"]
)

# OpenStreetMap Overpass API Endpoint
OVERPASS_URL = "https://overpass-api.de/api/interpreter"

def get_current_user(db: Session = Depends(get_db), x_username: str = Header(None)):
    """
    Authentication dependency using custom header. 
    In production, this should be replaced with JWT-based auth.
    """
    if not x_username:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="X-Username header missing"
        )
    user = db.query(models.User).filter(models.User.username == x_username).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid user"
        )
    return user

@router.get("/", response_model=Optional[schemas.LocationResponse])
def get_location(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    """
    Fetches the stored location for the authenticated user.
    Returns null if no location exists.
    """
    location = db.query(models.UserLocation).filter(models.UserLocation.user_id == current_user.id).first()
    return location

@router.post("/", response_model=schemas.LocationResponse)
def update_location(location_data: schemas.LocationUpdate, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    """
    Saves or updates the user's persistent location.
    Triggered when user clicks 'UPDATE' or saves for the first time.
    """
    db_location = db.query(models.UserLocation).filter(models.UserLocation.user_id == current_user.id).first()
    
    if db_location:
        db_location.latitude = location_data.latitude
        db_location.longitude = location_data.longitude
    else:
        db_location = models.UserLocation(
            user_id=current_user.id,
            latitude=location_data.latitude,
            longitude=location_data.longitude
        )
        db.add(db_location)
    
    db.commit()
    db.refresh(db_location)
    return db_location

@router.get("/nearby-services")
async def get_nearby_services(lat: float, lon: float):
    """
    Proxy request to Overpass API to fetch nearby medical services.
    RADIUS_METERS is hardcoded to 2000 for strict local medical relevance and performance.
    Results are post-validated using the Haversine formula.
    """
    import math

    # HARD SECURITY RULE: Radius is intentionally limited to 2km
    RADIUS_METERS = 2000

    def haversine_distance(lat1, lon1, lat2, lon2):
        """Calculates distance between two points in meters."""
        R = 6371000  # Earth radius in meters
        phi1, phi2 = math.radians(lat1), math.radians(lat2)
        dphi = math.radians(lat2 - lat1)
        dlambda = math.radians(lon2 - lon1)
        a = math.sin(dphi / 2)**2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2)**2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        return R * c

    # Overpass Query Language (QL) to fetch specific amenities
    query = f"""
    [out:json];
    (
      node["amenity"="doctors"](around:{RADIUS_METERS},{lat},{lon});
      way["amenity"="doctors"](around:{RADIUS_METERS},{lat},{lon});
      node["amenity"="clinic"](around:{RADIUS_METERS},{lat},{lon});
      way["amenity"="clinic"](around:{RADIUS_METERS},{lat},{lon});
      node["amenity"="hospital"](around:{RADIUS_METERS},{lat},{lon});
      way["amenity"="hospital"](around:{RADIUS_METERS},{lat},{lon});
    );
    out center;
    """
    
    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(OVERPASS_URL, data={"data": query}, timeout=15.0)
            response.raise_for_status()
            data = response.json()
            
            results = []
            for element in data.get("elements", []):
                tags = element.get("tags", {})
                name = tags.get("name", "Unnamed Medical Service")
                service_type = tags.get("amenity", "unknown").capitalize()
                
                e_lat = element.get("lat") or element.get("center", {}).get("lat")
                e_lon = element.get("lon") or element.get("center", {}).get("lon")
                
                if e_lat and e_lon:
                    # POST-VALIDATION: Strictly filter by distance
                    dist = haversine_distance(lat, lon, e_lat, e_lon)
                    if dist <= RADIUS_METERS:
                        results.append({
                            "name": name,
                            "type": service_type,
                            "lat": e_lat,
                            "lon": e_lon,
                            "distance_km": round(dist / 1000, 2),
                            "address": tags.get("addr:full") or tags.get("addr:street") or "Near your location",
                            "google_maps_url": f"https://www.google.com/maps/search/?api=1&query={e_lat},{e_lon}"
                        })
            
            # Sort results by closest distance
            results.sort(key=lambda x: x["distance_km"])
            return results
        except httpx.HTTPError as e:
            raise HTTPException(status_code=502, detail=f"Error fetching data from OSM: {str(e)}")
