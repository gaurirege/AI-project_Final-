from fastapi import APIRouter
from pydantic import BaseModel
from typing import List, Optional, Any, Dict
from .services.symptom_service import symptom_service
from .services.recommendation_service import recommendation_service

router = APIRouter()

class SymptomRequest(BaseModel):
    user_input: str
    language: str = "en"

class DiseaseResponse(BaseModel):
    disease_id: str
    name: str
    category: Optional[str] = None
    brief_description: Optional[str] = None
    symptoms: Optional[str] = None
    common_symptoms: Optional[str] = None
    severity: Optional[str] = None
    typical_age_groups: Optional[str] = None
    gender_impact: Optional[str] = None
    incidence_prevalence: Optional[str] = None
    red_flags: Optional[str] = None
    diagnostic_accuracy_notes: Optional[str] = None
    confidence: Optional[str] = None
    last_updated: Optional[str] = None
    typical_doc_types: Optional[str] = None
    matched_symptoms: List[str] = []
    sources: List[Any] = []

class PredictionResponse(BaseModel):
    diseases: Optional[List[DiseaseResponse]] = None
    recommendations: List[Dict[str, str]] = []
    message: Optional[str] = None

@router.get("/recommendations/general", tags=["Symptom Prediction"])
async def get_general_recommendations():
    """
    Get general health recommendations for users who haven't completed an assessment.
    """
    return recommendation_service.get_general_recommendations()

@router.post("/predict/symptoms", response_model=PredictionResponse, tags=["Symptom Prediction"])
async def predict_symptoms(request: SymptomRequest):
    """
    Predict diseases based on free-text symptom description.
    """
    if not request.user_input.strip():
        return {
            "message": symptom_service.get_no_match_message(request.language)
        }

    result = symptom_service.predict(request.user_input, request.language)
    
    # Enrich with Recommendations
    matched_symptoms = []
    disease_names = []
    
    if result["diseases"]:
        for d in result["diseases"]:
            disease_names.append(d["name"])
            matched_symptoms.extend(d["matched_symptoms"])
    
    # Ensure unique and filtered
    matched_symptoms = list(set(matched_symptoms))
    
    recommendations = recommendation_service.get_recommendations(matched_symptoms, disease_names)
    result["recommendations"] = recommendations
    
    if not result["diseases"]:
        # No match found - ensure we still have recommendations (fallback is handled by service)
        return {
            "message": symptom_service.get_no_match_message(request.language),
            "recommendations": recommendations
        }
    
    return result
