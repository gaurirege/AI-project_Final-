from fastapi import APIRouter, Depends, HTTPException, Header, status
from sqlalchemy.orm import Session
from typing import List
from . import models, schemas, database
from .database import get_db

router = APIRouter(prefix="/chat-history", tags=["Chat History"])

def get_current_user(db: Session = Depends(get_db), x_username: str = Header(None)):
    """
    Simple auth dependency that fetches user from DB based on X-Username header.
    In a real app, this would use JWT tokens.
    """
    if not x_username:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="X-Username header missing"
        )
    user = db.query(models.User).filter(models.User.username == x_username).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid user"
        )
    return user

@router.post("/save", response_model=schemas.ChatHistoryResponse)
def save_history(
    history_in: schemas.ChatHistoryCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    """
    Saves a prediction session to the user's history.
    """
    new_history = models.ChatHistory(
        user_id=current_user.id,
        user_message=history_in.user_message,
        prediction_result=history_in.prediction_result,
        language=history_in.language
    )
    db.add(new_history)
    db.commit()
    db.refresh(new_history)
    return new_history

@router.get("", response_model=List[schemas.ChatHistoryResponse])
def get_user_history(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    """
    Returns all chat history for the logged-in user, newest first.
    """
    return db.query(models.ChatHistory)\
        .filter(models.ChatHistory.user_id == current_user.id)\
        .order_by(models.ChatHistory.created_at.desc())\
        .all()

@router.delete("/{history_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_history_item(
    history_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    """
    Allows a user to delete their own history entry.
    """
    history_item = db.query(models.ChatHistory)\
        .filter(models.ChatHistory.id == history_id, models.ChatHistory.user_id == current_user.id)\
        .first()
    
    if not history_item:
        raise HTTPException(status_code=404, detail="History item not found")
    
    db.delete(history_item)
    db.commit()
    return None
