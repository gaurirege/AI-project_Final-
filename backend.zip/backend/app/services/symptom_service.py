import csv
import os
from typing import List, Dict, Optional
import logging

# Configure logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

class SymptomService:
    _instance = None
    _diseases: List[Dict] = []
    _provenance: Dict[str, Dict] = {}
    _data_loaded = False

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(SymptomService, cls).__new__(cls)
        return cls._instance

    def load_data(self):
        """
        Loads disease and provenance data from CSVs into memory.
        This should be called once at startup.
        """
        if self._data_loaded:
            return

        # Paths
        # Using relative paths assuming execution from backend/
        # Adjust as needed based on actual running directory or use absolute paths via os.path
        base_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        data_file = os.path.join(base_path, "DATA", "data_Version2.csv")
        provenance_file = os.path.join(base_path, "DATA", "provenance_merged_Version2.csv")

        # Load Provenance
        try:
            with open(provenance_file, mode='r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    # used_by_ids can be comma separated list "C001,C002"
                    ids = row.get("used_by_ids", "").replace('"', '').split(',')
                    entry = {
                        "page_title": row.get("page_title"),
                        "url": row.get("url"),
                        "date_accessed": row.get("date_accessed"),
                        "license_notes": row.get("license_notes")
                    }
                    for disease_id in ids:
                        clean_id = disease_id.strip()
                        if clean_id:
                            if clean_id not in self._provenance:
                                self._provenance[clean_id] = []
                            self._provenance[clean_id].append(entry)
            logger.info(f"Loaded provenance for {len(self._provenance)} disease IDs")
        except FileNotFoundError:
             logger.error(f"Provenance file not found at {provenance_file}")
        except Exception as e:
            logger.error(f"Error loading provenance: {e}")

        # Load Diseases
        try:
            with open(data_file, mode='r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    self._diseases.append(row)
            logger.info(f"Loaded {len(self._diseases)} diseases")
        except FileNotFoundError:
            logger.error(f"Data file not found at {data_file}")
        except Exception as e:
            logger.error(f"Error loading data: {e}")

        self._data_loaded = True

    def _normalize(self, text: str) -> str:
        """
        Lowercase and replace punctuation with spaces to preserve word boundaries.
        """
        import string
        import re
        text = text.lower()
        # Replace punctuation with space
        for char in string.punctuation:
            text = text.replace(char, ' ')
        # Collapse multiple spaces
        text = re.sub(r'\s+', ' ', text).strip()
        return text

    def predict(self, user_input: str, language: str) -> Dict:
        """
        Predict diseases based on user input.
        """
        import re
        
        if not self._data_loaded:
            self.load_data()

        # 1. Normalize Input
        normalized_input = self._normalize(user_input)
        
        matches = []

        for disease in self._diseases:
            d_id = disease.get("disease_id")
            
            # Fields to search
            # Treat symptoms as a list of distinct terms
            d_symptoms = [s.strip() for s in disease.get("symptoms", "").split(';')]
            d_common = [s.strip() for s in disease.get("common_symptoms", "").split(';')]
            d_synonyms = [s.strip() for s in disease.get("synonyms", "").split(';')]
            
            all_disease_terms = set(d_symptoms + d_common + d_synonyms)
            
            count = 0
            current_matched = []
            
            # Exact word/phrase matching using regex boundaries
            for term in all_disease_terms:
                norm_term = self._normalize(term)
                if not norm_term:
                    continue
                
                # Use regex to match whole word/phrase
                # escape the term to handle any regex special chars that might be in the text (rare but safe)
                pattern = r'\b' + re.escape(norm_term) + r'\b'
                
                if re.search(pattern, normalized_input):
                     count += 1
                     current_matched.append(term)
            
            if count > 0:
                # Add to results
                # Severity mapping for sorting
                sev_str = disease.get("severity", "").lower()
                severity_score = 0
                if "severe" in sev_str: severity_score = 3
                elif "moderate" in sev_str: severity_score = 2
                elif "mild" in sev_str: severity_score = 1
                
                # Get Sources
                sources = self._provenance.get(d_id, [])
                
                matches.append({
                    "disease_data": disease,
                    "score": count,
                    "severity_score": severity_score,
                    "matched_symptoms": list(set(current_matched)),
                    "sources": sources
                })

        # Ranking
        # 1. Highest matched symptom count
        # 2. Severity
        matches.sort(key=lambda x: (x["score"], x["severity_score"]), reverse=True)
        
        # Result formatting
        results = []
        for m in matches:
            d = m["disease_data"]
            results.append({
                "disease_id": d.get("disease_id"),
                "name": d.get("name"),
                "category": d.get("category"),
                "brief_description": d.get("brief_description"),
                "symptoms": d.get("symptoms"),
                "common_symptoms": d.get("common_symptoms"),
                "severity": d.get("severity"),
                "typical_age_groups": d.get("typical_age_groups"),
                "gender_impact": d.get("gender_impact"),
                "incidence_prevalence": d.get("incidence_prevalence"),
                "red_flags": d.get("red_flags"),
                "diagnostic_accuracy_notes": d.get("diagnostic_accuracy_notes"),
                "confidence": d.get("confidence"),
                "last_updated": d.get("last_updated"),
                "typical_doc_types": d.get("typical_doc_types"),
                "matched_symptoms": m["matched_symptoms"],
                "sources": m["sources"]
            })
            
        return {"diseases": results[:3]}

    def get_no_match_message(self, language: str) -> str:
        # Return English message. The frontend handles dynamic translation.
        return "These symptoms are not present in our database.\nWe appreciate your patience.\nMore disease-related data will be updated in the app soon."

# Global instance
symptom_service = SymptomService()
