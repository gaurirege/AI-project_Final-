from typing import List, Dict, Set

class RecommendationService:
    _instance = None

    # Static mapping of Symptoms/Diseases to Trusted Recommendations
    # Sources: WHO, NHS, CDC, Mayo Clinic
    _MAPPING = {
        # --- Symptoms ---
        "fever": [
            {"text": "Stay well-hydrated by drinking plenty of water and clear fluids.", "source": "WHO"},
            {"text": "Get adequate rest to help your body fight the infection.", "source": "Mayo Clinic"},
            {"text": "Monitor your temperature regularly and use lukewarm compresses if needed.", "source": "NHS"}
        ],
        "cough": [
            {"text": "Drink warm fluids like tea with honey to soothe the throat.", "source": "Mayo Clinic"},
            {"text": "Avoid irritants such as smoke, cold air, and strong perfumes.", "source": "CDC"},
            {"text": "Consider using a humidifier to keep the air moist.", "source": "NHS"}
        ],
        "sore throat": [
            {"text": "Gargle with warm salt water several times a day.", "source": "Mayo Clinic"},
            {"text": "Suck on throat lozenges or hard candy to keep the throat moist.", "source": "NHS"},
            {"text": "Rest your voice and avoid prolonged talking.", "source": "CDC"}
        ],
        "headache": [
            {"text": "Rest in a quiet, dark room until the pain subsides.", "source": "Mayo Clinic"},
            {"text": "Ensure you are getting enough sleep and managing stress.", "source": "NHS"},
            {"text": "Stay hydrated as dehydration can often trigger headaches.", "source": "WHO"}
        ],
        "fatigue": [
            {"text": "Prioritize sleep and maintain a consistent sleep schedule.", "source": "CDC"},
            {"text": "Eat a balanced diet to maintain steady energy levels.", "source": "WHO"},
            {"text": "Incorporate light physical activity, like walking, if possible.", "source": "NHS"}
        ],
        
        # --- Diseases ---
        "diabetes": [
            {"text": "Monitor your blood glucose levels regularly as advised by your doctor.", "source": "WHO"},
            {"text": "Follow a balanced, low-glycemic diet rich in fiber.", "source": "Mayo Clinic"},
            {"text": "Engage in regular physical activity to help manage blood sugar.", "source": "CDC"}
        ],
        "hypertension": [
            {"text": "Reduce salt intake in your diet to help lower blood pressure.", "source": "WHO"},
            {"text": "Monitor your blood pressure at home and keep a log.", "source": "NHS"},
            {"text": "Manage stress through relaxation techniques or physical activity.", "source": "Mayo Clinic"}
        ],
        "common cold": [
            {"text": "Drink plenty of fluids and get plenty of rest.", "source": "CDC"},
            {"text": "Over-the-counter saline nasal drops can help relieve congestion.", "source": "NHS"},
            {"text": "Wash your hands frequently to prevent spreading germs.", "source": "WHO"}
        ],
        "malaria": [
            {"text": "Complete the full course of prescribed antimalarial medication.", "source": "WHO"},
            {"text": "Use mosquito nets and repellents to prevent further bites.", "source": "CDC"},
            {"text": "Seek immediate medical attention if symptoms worsen.", "source": "NHS"}
        ],
        "dengue": [
            {"text": "Stay hydrated and rest to manage symptoms.", "source": "WHO"},
            {"text": "Avoid aspirin and ibuprofen; use paracetamol for pain/fever if advised.", "source": "CDC"},
            {"text": "Monitor for any signs of bleeding and seek urgent care if they occur.", "source": "NHS"}
        ]
    }

    _GENERAL_RECOMMENDATIONS = [
        {"text": "Eat a variety of fruits, vegetables, and whole grains daily.", "source": "WHO"},
        {"text": "Drink 8-10 glasses of water per day for optimal hydration.", "source": "NHS"},
        {"text": "Engage in at least 30 minutes of moderate physical activity most days.", "source": "CDC"},
        {"text": "Practice good hygiene by washing hands frequently with soap.", "source": "WHO"},
        {"text": "Maintain a consistent sleep schedule of 7-9 hours per night.", "source": "Mayo Clinic"}
    ]

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(RecommendationService, cls).__new__(cls)
        return cls._instance

    def get_recommendations(self, matched_symptoms: List[str], diseases: List[str]) -> List[Dict]:
        """
        Aggregates unique recommendations based on symptoms and diseases.
        Falls back to general recommendations if no matches are found.
        """
        combined_tips = []
        seen_texts = set()

        # 1. Check Diseases (Priority)
        for disease in diseases:
            norm_disease = disease.lower()
            if norm_disease in self._MAPPING:
                for tip in self._MAPPING[norm_disease]:
                    if tip["text"] not in seen_texts:
                        combined_tips.append(tip)
                        seen_texts.add(tip["text"])

        # 2. Check Symptoms
        for symptom in matched_symptoms:
            norm_symptom = symptom.lower()
            if norm_symptom in self._MAPPING:
                for tip in self._MAPPING[norm_symptom]:
                    if tip["text"] not in seen_texts:
                        combined_tips.append(tip)
                        seen_texts.add(tip["text"])

        # 3. Fallback to General
        if not combined_tips:
            return self._GENERAL_RECOMMENDATIONS
        
        return combined_tips[:6]  # Limit to top 6 tips for UI clarity

    def get_general_recommendations(self) -> List[Dict]:
        """
        Returns the standard list of general health advice.
        """
        return self._GENERAL_RECOMMENDATIONS

# Global instance
recommendation_service = RecommendationService()
