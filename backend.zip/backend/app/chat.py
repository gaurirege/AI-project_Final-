from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from datetime import datetime
from typing import Optional

# Create the router instance
router = APIRouter()

# --- Pydantic Models ---

class ChatRequest(BaseModel):
    message: str
    language: str = "en"  # Default to English
    user_id: Optional[str] = None

class ChatResponse(BaseModel):
    reply: str
    language: str
    timestamp: str

# --- Chat Endpoint ---

@router.post("/chat", response_model=ChatResponse, tags=["Chatbot"])
async def chat_with_ella(request: ChatRequest):
    """
    Chatbot endpoint for Ella.
    Receives a message (usually in English after frontend translation) 
    and returns an English response.
    """
    
    user_msg = request.message.strip()
    
    # 1. Simple Logic / Rule-based Brain
    # In the future, integrate LLM here.
    
    response_text = ""
    
    if not user_msg:
        response_text = "I didn't hear anything. Could you please repeat?"
    elif "hello" in user_msg.lower() or "hi" in user_msg.lower():
        response_text = "Hello! I am Ella. How are you feeling today?"
    elif "fever" in user_msg.lower() or "temp" in user_msg.lower():
        response_text = "I understand you might have a fever. Could you tell me your body temperature?"
    elif "headache" in user_msg.lower():
        response_text = "Headaches can be tough. Are you experiencing any sensitivity to light?"
    else:
        # Generic fallback
        response_text = f"I noted: '{user_msg}'. Please tell me more about your symptoms."

    # 2. Return JSON Response
    return {
        "reply": response_text,
        "language": "en", # Backend responds in English, Frontend translates it.
        "timestamp": datetime.now().isoformat()
    }
