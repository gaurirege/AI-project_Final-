from pydantic import BaseModel, EmailStr, Field, field_validator
from datetime import datetime
from typing import Any, Dict, Optional

class UserBase(BaseModel):
    username: str
    email: EmailStr

class UserCreate(UserBase):
    password: str = Field(..., min_length=6)

class UserLogin(BaseModel):
    username: str
    password: str

class UserResponse(UserBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True

class ChatHistoryCreate(BaseModel):
    user_message: str
    prediction_result: Dict[str, Any]
    language: str = "en"

class ChatHistoryResponse(BaseModel):
    id: int
    user_id: int
    user_message: str
    prediction_result: Dict[str, Any]
    language: str
    created_at: datetime

    class Config:
        from_attributes = True

# --- Location & Nearby Services Schemas ---

class LocationBase(BaseModel):
    latitude: float
    longitude: float

class LocationCreate(LocationBase):
    pass

class LocationUpdate(LocationBase):
    pass

class LocationResponse(LocationBase):
    user_id: int
    updated_at: datetime

    class Config:
        from_attributes = True
