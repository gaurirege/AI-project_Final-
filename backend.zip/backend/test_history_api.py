import requests
import json

BASE_URL = "http://10.134.194.22:8000"
USERNAME = "testuser"
EMAIL = "test@example.com"
PASSWORD = "password123"

def test_chat_history():
    print("--- Testing Chat History API ---")
    
    # 1. Ensure user exists (or sign up)
    signup_data = {
        "username": USERNAME,
        "email": EMAIL,
        "password": PASSWORD
    }
    requests.post(f"{BASE_URL}/signup", json=signup_data)
    
    # 2. Login (to verify creds, although our header auth is simple)
    login_data = {"username": USERNAME, "password": PASSWORD}
    login_res = requests.post(f"{BASE_URL}/login", json=login_data)
    if login_res.status_code != 200:
        print("Login failed, user might already exist. Proceeding...")

    headers = {"X-Username": USERNAME}

    # 3. Save a history entry
    history_entry = {
        "user_message": "I have a severe headache and fever",
        "prediction_result": {
            "diseases": [
                {
                    "name": "Migraine",
                    "confidence": "85%",
                    "typical_doc_types": "Neurologist",
                    "sources": [{"label": "WebMD", "url": "https://www.webmd.com"}]
                }
            ]
        },
        "language": "en"
    }
    
    save_res = requests.post(f"{BASE_URL}/chat-history/save", json=history_entry, headers=headers)
    assert save_res.status_code == 200, f"Save failed: {save_res.text}"
    saved_id = save_res.json()["id"]
    print(f"Successfully saved history entry: ID {saved_id}")

    # 4. Get history
    get_res = requests.get(f"{BASE_URL}/chat-history", headers=headers)
    assert get_res.status_code == 200
    history_list = get_res.json()
    assert len(history_list) > 0
    print(f"Successfully retrieved {len(history_list)} history items")
    print(f"First item summary: {history_list[0]['user_message']}")

    # 5. Delete entry (optional check)
    # delete_res = requests.delete(f"{BASE_URL}/chat-history/{saved_id}", headers=headers)
    # assert delete_res.status_code == 204
    # print(f"Successfully deleted history entry: ID {saved_id}")

    print("--- Chat History API Test Passed ---")

if __name__ == "__main__":
    try:
        test_chat_history()
    except Exception as e:
        print(f"Test failed: {e}")
