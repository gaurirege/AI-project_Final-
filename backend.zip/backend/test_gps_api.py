import requests

BASE_URL = "http://10.134.194.22:8000"
USERNAME = "testuser_gps"

def test_location_api():
    print("Testing Location API...")
    
    # 1. Signup test user
    signup_data = {"username": USERNAME, "email": f"{USERNAME}@example.com", "password": "password123"}
    resp = requests.post(f"{BASE_URL}/signup", json=signup_data)
    if resp.status_code == 400:
        print("User already exists, proceeding...")
    
    # 2. Get location (should be None)
    resp = requests.get(f"{BASE_URL}/location/", headers={"X-Username": USERNAME})
    print(f"Initial location: {resp.json()}")
    
    # 3. Update location
    loc_data = {"latitude": 18.5204, "longitude": 73.8567} # Pune, India
    resp = requests.post(f"{BASE_URL}/location/", json=loc_data, headers={"X-Username": USERNAME})
    print(f"Update response: {resp.status_code}, {resp.json()}")
    
    # 4. Get location again
    resp = requests.get(f"{BASE_URL}/location/", headers={"X-Username": USERNAME})
    print(f"Fetched location: {resp.json()}")
    
    # 5. Test OSM Proxy
    print("Testing OSM Proxy...")
    resp = requests.get(f"{BASE_URL}/location/nearby-services?lat=18.5204&lon=73.8567")
    print(f"OSM Proxy response code: {resp.status_code}")
    if resp.status_code == 200:
        results = resp.json()
        print(f"Found {len(results)} medical services nearby.")
        if len(results) > 0:
            print(f"Sample result: {results[0]}")

if __name__ == "__main__":
    test_location_api()
